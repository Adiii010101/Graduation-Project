activate virtual env

ml\Scripts\activate

run project

python try.py

api base url
http://127.0.0.1:5000
use this url it will remain constant 